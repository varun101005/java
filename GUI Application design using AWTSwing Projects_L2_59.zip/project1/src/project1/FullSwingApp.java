package project1;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FullSwingApp extends Canvas {
	private static final long serialVersionUID = -313509439754083055L;

	@Override
    public void paint(Graphics g) {
        g.drawString("Hello", 40, 40);
        setBackground(Color.WHITE);
        g.fillRect(130, 30, 100, 80);               
        g.drawOval(30, 130, 50, 60);              
        g.setColor(Color.RED);
        g.fillOval(130, 130, 50, 60);              
        g.setColor(Color.BLACK);
        g.drawArc(30, 200, 40, 50, 90, 60);         
        g.fillArc(30, 130, 40, 50, 180, 40);       
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Full Swing GUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 700);
        frame.setLayout(new FlowLayout());
        JTextField t1 = new JTextField(10);

        JRadioButton r1 = new JRadioButton("Male");
        JRadioButton r2 = new JRadioButton("Female");
        ButtonGroup bg = new ButtonGroup();
        bg.add(r1);
        bg.add(r2);

        JCheckBox c1 = new JCheckBox("Likes Coffee");
        JCheckBox c2 = new JCheckBox("Likes Tea");

        JButton b1 = new JButton("Submit Details");
        JLabel l1 = new JLabel("Greetings.");

        frame.add(new JLabel("Enter your name:"));
        frame.add(t1);
        frame.add(r1);
        frame.add(r2);
        frame.add(c1);
        frame.add(c2);
        frame.add(b1);
        frame.add(l1);

        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = t1.getText();
                if (r1.isSelected()) name = "Mr. " + name;
                else if (r2.isSelected()) name = "Ms. " + name;

                if (c1.isSelected()) name += " likes coffee";
                if (c2.isSelected()) name += ", likes tea";

                l1.setText(name);
            }
        });
        String[] columns = {"Id", "Name", "Age"};
        String[][] data = {
            {"1", "Amit Kumar", "29"},
            {"2", "Atul Kumar", "29"},
            {"3", "Anuj Kumar", "29"}
        };
        JTable jt = new JTable(data, columns);
        JScrollPane jsp = new JScrollPane(jt);
        jsp.setPreferredSize(new Dimension(300, 80));
        frame.add(jsp);
        String[] groceryItems = {"Bread", "Coffee", "Tea", "Butter", "Milk"};

        JList<String> jl = new JList<>(groceryItems);
        jl.setVisibleRowCount(3);
        JScrollPane listScroll = new JScrollPane(jl);
        listScroll.setPreferredSize(new Dimension(100, 70));
        frame.add(new JLabel("Grocery List:"));
        frame.add(listScroll);

        JComboBox<String> jcb = new JComboBox<>(groceryItems);
        frame.add(new JLabel("Select item:"));
        frame.add(jcb);
        JScrollBar jsb = new JScrollBar(JScrollBar.HORIZONTAL, 0, 20, 0, 100);
        jsb.setPreferredSize(new Dimension(300, 20));
        frame.add(new JLabel("Adjust Scroll:"));
        frame.add(jsb);
        FullSwingApp canvas = new FullSwingApp();
        canvas.setPreferredSize(new Dimension(400, 300));
        frame.add(canvas);
        frame.setVisible(true);
    }
}
