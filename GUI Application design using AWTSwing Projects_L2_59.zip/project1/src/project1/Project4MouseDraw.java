package project1;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Project4MouseDraw extends MouseMotionAdapter {
    JFrame frame;
    JPanel panel;

    public static void main(String[] args) {
        new Project4MouseDraw();
    }

    Project4MouseDraw() {
        frame = new JFrame("Mouse Motion Drawing");

        // Create a drawing panel
        panel = new JPanel() {
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
            }
        };

        panel.setBackground(Color.WHITE);
        panel.addMouseMotionListener(this);

        frame.add(panel);
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public void mouseDragged(MouseEvent e) {
        Graphics g = panel.getGraphics();
        g.setColor(Color.RED);
        g.fillRect(e.getX(), e.getY(), 5, 5);
    }
}
