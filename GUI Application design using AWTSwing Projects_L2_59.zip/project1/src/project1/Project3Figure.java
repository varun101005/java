package project1;
import javax.swing.*;
import java.awt.*;

public class Project3Figure extends Canvas {
	private static final long serialVersionUID = 1L;

	@Override
    public void paint(Graphics g) {
        g.drawOval(120, 60, 30, 30);
        g.drawOval(290, 60, 30, 30);
        setForeground(Color.RED);
        g.fillOval(160, 60, 30, 30);
        g.fillOval(250, 60, 30, 30);
        setForeground(Color.BLACK);
        g.drawArc(200, 60, 50, 50, 240, 60);
        g.drawRect(150, 40, 140, 90);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Project 3: Draw Figure");
        Project3Figure canvas = new Project3Figure();
        canvas.setBackground(Color.WHITE);
        canvas.setSize(500, 500);
        frame.add(canvas);
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
