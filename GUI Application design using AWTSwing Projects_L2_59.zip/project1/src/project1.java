import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class project1 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Add Two Numbers");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 150);
        frame.setLayout(new FlowLayout());

        JTextField t1 = new JTextField(5);
        JTextField t2 = new JTextField(5);

        JButton b1 = new JButton("+");

        JLabel l1 = new JLabel("Output");

        frame.add(t1);
        frame.add(t2);
        frame.add(b1);
        frame.add(l1);

        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int a = Integer.parseInt(t1.getText());
                    int b = Integer.parseInt(t2.getText());
                    int c = a + b;
                    l1.setText("Result: " + c);
                } catch (NumberFormatException ex) {
                    l1.setText("Please enter valid numbers!");
                }
            }
        });

        frame.setVisible(true);
    }
}
